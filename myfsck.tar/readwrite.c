/* $cmuPDL: readwrite.c,v 1.3 2010/02/27 11:38:39 rajas Exp $ */
/* $cmuPDL: readwrite.c,v 1.4 2014/01/26 21:16:20 avjaltad Exp $ */
/* readwrite.c
 *
 * Code to read and write sectors to a "disk" file.
 * This is a support file for the "fsck" storage systems laboratory.
 *
 * author: Sky Dragon 
 */
#include "myfsck.h"

#define __FreeBSD__

#if defined(__FreeBSD__)
#define lseek64 lseek
#endif

/* linux: lseek64 declaration needed here to eliminate compiler warning. */
extern int64_t lseek64(int, int64_t, int);
//extern int opterr;
extern char *optarg;
extern int optind, opterr, optop;
const unsigned int sector_size_bytes = 512;

static int device;  /* disk file descriptor */

/* print_sector: print the contents of a buffer containing one sector.
 *
 * inputs:
 *   char *buf: buffer must be >= 512 bytes.
 *
 * outputs:
 *   the first 512 bytes of char *buf are printed to stdout.
 *
 * modifies:
 *   (none)
 */
void print_sector (unsigned char *buf)
{
    int i;
    for (i = 0; i < sector_size_bytes; i++) {
        printf("%02x", buf[i]);
        if (!((i+1) % 32))
            printf("\n");      /* line break after 32 bytes */
        else if (!((i+1) % 4))
            printf(" ");   /* space after 4 bytes */
    }
}


/* read_sectors: read a specified number of sectors into a buffer.
 *
 * inputs:
 *   int64 start_sector: the starting sector number to read.
 *                       sector numbering starts with 0.
 *   int numsectors: the number of sectors to read.  must be >= 1.
 *   int device [GLOBAL]: the disk from which to read.
 *
 * outputs:
 *   void *into: the requested number of sectors are copied into here.
 *
 * modifies:
 *   void *into
 */
void read_sectors (int64_t start_sector, unsigned int num_sectors, void *into)
{
    ssize_t ret;
    int64_t lret;
    int64_t sector_offset;
    ssize_t bytes_to_read;

    if (num_sectors == 1) {
      //  printf("Reading sector %"PRId64"\n", start_sector);
    } else {
       // printf("Reading sectors %"PRId64"--%"PRId64"\n",
               //start_sector, start_sector + (num_sectors - 1));
    }

    sector_offset = start_sector * sector_size_bytes;

    if ((lret = lseek64(device, sector_offset, SEEK_SET)) != sector_offset) {
        fprintf(stderr, "Seek to position %"PRId64" failed: "
                "returned %"PRId64"\n", sector_offset, lret);
        exit(-1);
    }

    bytes_to_read = sector_size_bytes * num_sectors;

    if ((ret = read(device, into, bytes_to_read)) != bytes_to_read) {
        fprintf(stderr, "Read sector %"PRId64" length %d failed: "
                "returned %"PRId64"\n", start_sector, num_sectors, (long long)ret);
        exit(-1);
    }
}


/* write_sectors: write a buffer into a specified number of sectors.
 *
 * inputs:
 *   int64 start_sector: the starting sector number to write.
 *                	sector numbering starts with 0.
 *   int numsectors: the number of sectors to write.  must be >= 1.
 *   void *from: the requested number of sectors are copied from here.
 *
 * outputs:
 *   int device [GLOBAL]: the disk into which to write.
 *
 * modifies:
 *   int device [GLOBAL]
 */
void write_sectors (int64_t start_sector, unsigned int num_sectors, void *from)
{
    ssize_t ret;
    int64_t lret;
    int64_t sector_offset;
    ssize_t bytes_to_write;

    if (num_sectors == 1) {
        printf("Reading sector  %"PRId64"\n", start_sector);
    } else {
        printf("Reading sectors %"PRId64"--%"PRId64"\n",
               start_sector, start_sector + (num_sectors - 1));
    }

    sector_offset = start_sector * sector_size_bytes;

    if ((lret = lseek64(device, sector_offset, SEEK_SET)) != sector_offset) {
        fprintf(stderr, "Seek to position %"PRId64" failed: "
                "returned %"PRId64"\n", sector_offset, lret);
        exit(-1);
    }

    bytes_to_write = sector_size_bytes * num_sectors;

    if ((ret = write(device, from, bytes_to_write)) != bytes_to_write) {
        fprintf(stderr, "Write sector %"PRId64" length %d failed: "
                "returned %"PRId64"\n", start_sector, num_sectors, (long long)ret);
        exit(-1);
    }
}

int main (int argc, char **argv)
{
    unsigned char buf[sector_size_bytes];        
    int the_sector;                     
	ptrEntites ptren;
	ptren.count = 0;
	ptren.p = NULL;
	int count = 0, i, j;

	char opt;
	char *path;
	int partitionNum = -1;
	bool isFindPartition = false;
	
	while((opt = getopt(argc, argv, "p:i:")) != -1){
		switch(opt){
			case 'p':
				partitionNum = atoi(optarg);	
				break;
			case 'i':
				path = optarg;
				break;
			default:
				printf("Correct usage:---");
				break;
		}
	}
    if ((device = open(path, O_RDWR)) == -1) {
        perror("Could not open device file");
        exit(-1);
    }

    the_sector = 0;
//    printf("Dumping sector %d:\n", the_sector);
    read_sectors(the_sector, 1, buf);
    //print_sector(buf);

	int off = 446;
    int nextsector;
    unsigned int base0x83 = 0;
    unsigned int base0x05 = 0;
	for(i = 0; i < 4; i++){
		ptren.count++;
		PTE *pte = (PTE *)malloc(sizeof(PTE));
		pte->next = NULL;
		pte->p = (partition *)malloc(sizeof(partition));
		memcpy(pte->p, (buf + off) + i * 16, 16);
		pte->index = ++count;
		
        if(pte->index == partitionNum){
           printf("0x%02X %d %d\n", pte->p->sys_ind, pte->p->start_sect, pte->p->nr_sects); 
			isFindPartition = true;
		}

		if(pte->p->sys_ind == 0x05){ 
		   base0x05 = pte->p->start_sect;
           nextsector = base0x05;
	    	//printf("Got a ebr 0x%02X %d %d\n", pte->p->sys_ind, pte->p->start_sect, pte->p->nr_sects);
		}else if(pte->p->sys_ind == 0x83){
           base0x83 = pte->p->start_sect; 
        }
		pte->next = ptren.p;
		ptren.p = pte;	
	}

    int finished = 0;
    for(i = 0; i < 4; i++){
	   read_sectors(nextsector, 1, buf);	
	   for(j = 0; j < 4; j++){
          partition p = *(partition *)(buf + off + j * 16);
          if(p.sys_ind == 0x05){
             nextsector = base0x05 + p.start_sect;
             break;
          }else if(p.sys_ind == 0x00){
             finished = 1;
             break;
          }

          PTE *pte = (PTE *)malloc(sizeof(PTE));
	      pte->next = NULL;
	      pte->p = (partition *)malloc(sizeof(partition));
		  memcpy(pte->p, buf + off + j * 16, 16);
          pte->p->start_sect += nextsector;
		  ptren.count++;
		  pte->index = ++count;
          if(pte->index == partitionNum){
             printf("0x%02X %d %d\n", pte->p->sys_ind, pte->p->start_sect, pte->p->nr_sects); 
          	isFindPartition = true;
		  }

	      pte->next = ptren.p;
   	      ptren.p = pte;
        }
        if(finished){
            break;
        }
	}
	if(!isFindPartition)
	    printf("-1\n");

	PTE *ne = ptren.p;
	for(i = 0; i < ptren.count; i++){
		//printf("partition num %d, 0x%02X %d %d\n", ne->index, ne->p->sys_ind, ne->p->start_sect, ne->p->nr_sects);	
		if(ne->index == partitionNum){
		//	printf("0x%02X %d %d\n", ne->p->sys_ind, ne->p->start_sect, ne->p->nr_sects);	
			goto done;
		}
		ne = ne->next;
	}	

done:	
	close(device);
	return 0;
}

