#ifndef TOOL_H
#define TOOL_H

int readEBR(PTE *ptr, char *buffer, int off, int num);

#endif

